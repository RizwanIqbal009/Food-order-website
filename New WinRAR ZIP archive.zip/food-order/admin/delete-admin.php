<?php
include('../config/constants.php');
//1. get id of admin to be deleted
//2.create sql query to delete admin
//redirect with message
 $id=$_GET['id'];
 $sql="DELETE FROM tbl_admin WHERE id=$id";
 //execution of query
 $res=mysqli_query($conn,$sql);

//checking the query
if($res==TRUE)
{
//create session variable to display message
$_SESSION['delete']="<div class='success'>Admin Deleted</div>";
header('location:'.SITEURL.'admin/manage-admin.php');
}
else
{
//create session variable to display message
$_SESSION['delete']="<div class='error'>Admin not Deleted</div>";
header('location:'.SITEURL.'admin/manage-admin.php');
}

?>