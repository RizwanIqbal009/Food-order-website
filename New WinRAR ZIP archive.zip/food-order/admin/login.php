<?php  include('../config/constants.php'); ?>
<html>    
<head>    
    <title>Login Form</title>    
    <link rel="stylesheet" type="text/css" href="../css/admin.css">    
</head>    
<body class="change">    
    <h2>Login Page</h2><br>    
    <div class="login">  
    <br>
    <?php
     if(isset($_SESSION['login']))
     {
           echo $_SESSION['login'];//Display message on adding
           unset($_SESSION['login']);//message will removed after refresh
     }
    ?>
    <br><br>

    <form id="login" method="POST" action="">    
        <label><b>User Name     
        </b>    
        </label>    
        <input type="text" name="username" id="Uname" placeholder="username">    
        <br><br>    
        <label><b>Password     
        </b>    
        </label>    
        <input type="Password" name="password" id="Pass" placeholder="password">    
        <br><br>    
        <input type="submit" name="submit" id="log" value="Log In Here">       
        <br><br>    
          
    </form>     
</div>    
</body>    
</html>    

<?php

//check wether the submit button is clicked or not
if(isset($_POST['submit']))
{
//get the data from login form
echo $username=$_POST['username'];
echo $password=$_POST['password'];


$sql="SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";
//exceutr the query

$res=mysqli_query($conn, $sql);

$count=mysqli_num_rows($res);

if($count==1)
{
    //user available
    $_SESSION['login']="<div class='success'> login Successfully.</div>";
    header('location:'.SITEURL.'admin/');

}
else 
{
    $_SESSION['login']="<div class='error text-center'> login Failed.</div>";
    header('location:'.SITEURL.'admin/login.php');

}

}


?>
